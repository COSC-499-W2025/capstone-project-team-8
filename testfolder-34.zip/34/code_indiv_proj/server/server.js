import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

// Twitch API configuration
const TWITCH_CLIENT_ID = process.env.TWITCH_CLIENT_ID;
const TWITCH_CLIENT_SECRET = process.env.TWITCH_CLIENT_SECRET;
let twitchAccessToken = null;
let tokenExpiresAt = 0;

// Middleware
app.use(cors({
  origin: [
    'http://localhost:3000',
    'https://fundzle.com',
    'https://www.fundzle.com',
  ],
  credentials: true,
}));
app.use(express.json());

// Get Twitch OAuth token
const getTwitchToken = async () => {
  const now = Date.now();
  
  // Return cached token if still valid
  if (twitchAccessToken && now < tokenExpiresAt) {
    return twitchAccessToken;
  }

  try {
    console.log('Getting new Twitch token...');
    const response = await fetch('https://id.twitch.tv/oauth2/token', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({
        client_id: TWITCH_CLIENT_ID,
        client_secret: TWITCH_CLIENT_SECRET,
        grant_type: 'client_credentials',
      }),
    });

    const data = await response.json();
    console.log('Twitch token response status:', response.status);
    console.log('Twitch token response:', data);
    
    if (data.access_token) {
      twitchAccessToken = data.access_token;
      // Set expiry to 1 hour from now (Twitch tokens last ~60 days but we refresh hourly)
      tokenExpiresAt = now + (data.expires_in * 1000);
      console.log('Got new token successfully');
      return twitchAccessToken;
    } else {
      console.error('No access token in Twitch response');
    }
  } catch (error) {
    console.error('Error getting Twitch token:', error);
  }

  return null;
};

// Check if streamers are live
app.post('/api/check-live', async (req, res) => {
  try {
    const { usernames } = req.body;
    console.log('Checking live status for:', usernames);

    if (!usernames || !Array.isArray(usernames)) {
      return res.status(400).json({ error: 'usernames array required' });
    }

    const token = await getTwitchToken();
    if (!token) {
      console.error('Failed to get Twitch token');
      return res.status(500).json({ error: 'Could not authenticate with Twitch' });
    }

    // Build query string for usernames
    const userQuery = usernames.map((name) => `user_login=${encodeURIComponent(name)}`).join('&');
    const apiUrl = `https://api.twitch.tv/helix/streams?${userQuery}`;
    console.log('Making Twitch API request to:', apiUrl);

    const response = await fetch(apiUrl, {
      headers: {
        'Client-ID': TWITCH_CLIENT_ID,
        'Authorization': `Bearer ${token}`,
      },
    });

    console.log('Twitch API response status:', response.status);

    if (!response.ok) {
      const errorText = await response.text();
      console.error('Twitch API error:', response.status, response.statusText, errorText);
      return res.status(500).json({ error: 'Twitch API error' });
    }

    const data = await response.json();
    console.log('Twitch API returned', data.data?.length || 0, 'live streams');

    // Create a map of live users
    const liveUsers = new Set(
      (data.data || []).map((stream) => stream.user_login)
    );

    // Return status for each username
    const result = {};
    usernames.forEach((username) => {
      result[username] = liveUsers.has(username);
    });

    console.log('Live status result:', result);
    res.json(result);
  } catch (error) {
    console.error('Error checking live status:', error);
    res.status(500).json({ error: 'Failed to check live status' });
  }
});

// Routes
app.get('/api/data', (req, res) => {
  res.json({ message: 'Hello from backend' });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
}).on('error', (err) => {
  console.error('Server error:', err);
  process.exit(1);
});

process.on('uncaughtException', (err) => {
  console.error('Uncaught Exception:', err);
  process.exit(1);
});