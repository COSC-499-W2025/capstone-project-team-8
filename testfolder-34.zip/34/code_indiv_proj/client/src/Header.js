import './Header.css';
import { Link, useLocation } from 'react-router-dom';

function Header() {
  const location = useLocation();

  const navItems = [
    { label: 'Home', abbrev: 'H', path: '/' },
    { label: 'Blog', abbrev: 'B', path: '/blog' },
    { label: 'Albums', abbrev: 'A', path: '/albums' },
    { label: 'Post-It Board', abbrev: 'P', path: '/post-it-board' },
    { label: 'TV Station', abbrev: 'T', path: '/webcams' },
  ];

  return (
    <header className="Header">
      <nav className="HeaderNav">
        {navItems.map((item) => (
          <Link
            key={item.path}
            to={item.path}
            className={`NavLink ${location.pathname === item.path ? 'active' : ''}`}
            data-label={item.label}
            data-abbrev={item.abbrev}
          >
            <span className="NavText">{item.label}</span>
          </Link>
        ))}
      </nav>
    </header>
  );
}

export default Header;
