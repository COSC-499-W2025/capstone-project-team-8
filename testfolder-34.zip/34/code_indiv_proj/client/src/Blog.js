import { useState } from 'react';
import './Blog.css';

const blogAscii = `______ _             
| ___ \\ |            
| |_/ / | ___   __ _ 
| ___ \\ |/ _ \\ / _\` |
| |_/ / | (_) | (_| |
\\____/|_|\\___/ \\__, |
                __/ |
               |___/ `;

const blogPosts = [
  {
    id: 1,
    title: 'Chicago Bears saved my life',
    date: '2025-12-21',
    content: 'Semester is done, vibe coding is back. Got a lil tv station thing set up now but that\'s all thats really new for now. Wolves > OKC and they will win it all. Chicago Bears lowkey my new favourite team Caleb Willaims is nice, that last throw actually blew my mind. More massive updates to come - Harper',
  },
  {
    id: 2,
    title: 'Massive Beginnings',
    date: '2025-12-16',
    content: 'This all started because I needed a little extra stimulation while watching assigned movies for class. Instagram Reels had a heavy influence in me wanting to do this too lol. Idk what ima end up posting here but ill try my best to keep this part active and use it as a mini online journal? Can\'t really say for certain only time will tell I guess. - Harper',
  },
  {
    id: 3,
    title: 'MIKE Supremacy',
    date: '2025-12-16',
    content: 'This is really just to fill the blog spaces for now so things don\'t look so empty and lame. But while I have your attention I want to encourage everyone to listen to MIKE, Showbiz! was AOTY for me, had it on repeat constantly - Harper',
  },

];

function Blog() {
  const [selectedPost, setSelectedPost] = useState(null);

  const handleClose = () => {
    setSelectedPost(null);
  };

  return (
    <div className="BlogContainer">
      <div className="BlogAsciiWrapper">
        <pre className="BlogAscii BlogAsciiDisplay">{blogAscii}</pre>
        <h1 className="BlogTitle BlogTextDisplay">Blog</h1>
      </div>
      <div className="TerminalWindow">
        <div className="TerminalHeader">
          <span className="TerminalTitle">blog@portfolio:~$</span>
        </div>
        <div className="TerminalContent">
          <div className="PostList">
            {blogPosts.map((post) => (
              <div
                key={post.id}
                className="PostLine"
                onClick={() => setSelectedPost(post)}
              >
                <span className="TerminalPrompt">PS my-app$</span>
                <span className="PostTitle">{post.title}</span>
                <span className="PostDate">{post.date}</span>
              </div>
            ))}
          </div>
          <div className="TerminalPrompt">
            PS my-app$ <span className="TerminalCursor">█</span>
          </div>
        </div>
      </div>

      {selectedPost && (
        <div className="ModalOverlay" onClick={handleClose}>
          <div className="ModalWindow" onClick={(e) => e.stopPropagation()}>
            <div className="ModalHeader">
              <span className="ModalTitle">blog@portfolio:~$ cat {selectedPost.title}</span>
              <button className="CloseButton" onClick={handleClose}>×</button>
            </div>
            <div className="ModalContent">
              <div className="PostHeader">
                <h2>{selectedPost.title}</h2>
                <p className="PostDate">{selectedPost.date}</p>
              </div>
              <div className="PostBody">
                {selectedPost.content}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default Blog;
