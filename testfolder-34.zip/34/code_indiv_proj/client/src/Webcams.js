import { useState, useEffect } from 'react';
import './Webcams.css';

function Webcams() {
  const [currentChannel, setCurrentChannel] = useState(0);
  const [liveStatus, setLiveStatus] = useState({});

  const channels = [
    { number: 1, name: 'Your Rage Gaming', username: 'yourragegaming' },
    { number: 2, name: 'The Burnt Peanut', username: 'theburntpeanut' },
    { number: 3, name: 'Benda Donn', username: 'bendadonnn' },
    { number: 4, name: 'QT Cinderella', username: 'qtcinderella' },
    { number: 5, name: 'Cinna', username: 'cinna' },
    { number: 6, name: 'Lacy', username: 'lacy' },
    { number: 7, name: 'Silky', username: 'silky' },
    { number: 8, name: 'Plaque Boy Max', username: 'plaqueboymax' },
    { number: 9, name: 'Jason the Ween', username: 'jasontheween' },
    { number: 10, name: 'Stable Ronaldo', username: 'stableronaldo' },
    { number: 11, name: 'Nadeshot', username: 'nadeshot' },
    { number: 12, name: 'Adapt', username: 'adapt' },
    { number: 13, name: 'ABS Arkilla', username: 'abstarkilla' },
    { number: 14, name: 'Bruce Drop Emoff', username: 'brucedropemoff' },
    { number: 15, name: 'SK4T Pack', username: 'sk4tpack' },
    { number: 16, name: 'Jurandle30', username: 'jurandle30' },
    { number: 17, name: 'K7YS7N', username: 'k7ys7n' },
    { number: 18, name: 'KaySan', username: 'kaysan' },
    { number: 19, name: 'Mari', username: 'mari' },
    { number: 20, name: 'Chillhop Radio', username: 'chillhopradio' },
    { number: 21, name: 'San Diego Webcam', username: 'sandiegowebcam' },
    { number: 22, name: 'cashidontget', username: 'cashidontget' },
    
  ];

  // Check live status on load and refresh every 30 seconds
  useEffect(() => {
    const checkLiveStatus = async () => {
      try {
        const usernames = channels.map((ch) => ch.username);
        const apiUrl = (process.env.REACT_APP_API_URL || 'http://localhost:5000').replace(/\/$/, '');
        const response = await fetch(`${apiUrl}/api/check-live`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ usernames }),
        });

        if (response.ok) {
          const data = await response.json();
          setLiveStatus(data);
          
          // On initial load, find and set the first available live channel
          setCurrentChannel((prevChannel) => {
            // Check if the current channel is live
            if (data[channels[prevChannel].username]) {
              return prevChannel;
            }
            
            // Find the first live channel
            const firstLiveIndex = channels.findIndex((ch) => data[ch.username]);
            return firstLiveIndex !== -1 ? firstLiveIndex : prevChannel;
          });
        }
      } catch (error) {
        console.error('Error checking live status:', error);
      }
    };

    checkLiveStatus();

    // Refresh every 30 seconds
    const interval = setInterval(checkLiveStatus, 30000);
    return () => clearInterval(interval);
  }, []);

  const currentChannelData = channels[currentChannel];
  const isLive = liveStatus[currentChannelData.username];

  const handleChannelChange = (index) => {
    setCurrentChannel(index);
  };

  return (
    <div className="TVContainer">
      <div className="StationTitle">
        <pre>{`_____ _   _            _____ _        _   _             
|_   _| | | |          /  ___| |      | | (_)            
  | | | | | |  ______  \\ \`--.| |_ __ _| |_ _  ___  _ __  
  | | | | | | |______|  \`--. \\ __/ _\` | __| |/ _ \\| '_ \\ 
  | | \\ \\_/ /          /\\__/ / || (_| | |_| | (_) | | | |
  \\_/  \\___/           \\____/ \\__\\__,_|\\__|_|\\___/|_| |_|`}</pre>
      </div>
      <div className="TVScreen">
        <div className="ScreenBezel">
          <div className="ChannelHeader">
            <span className="ChannelNumber">CH {currentChannelData.number}</span>
            <span className="ChannelName">{currentChannelData.name}</span>
            {isLive ? (
              <span className="LiveBadge">● LIVE</span>
            ) : (
              <span className="OfflineBadge">OFFLINE</span>
            )}
          </div>

          <div className="TwitchEmbed">
            <iframe
              src={`https://player.twitch.tv/?channel=${currentChannelData.username}&parent=localhost&parent=${window.location.hostname}`}
              height="600"
              width="100%"
              allowFullScreen
              frameBorder="0"
              allow="autoplay; encrypted-media"
              title={currentChannelData.name}
            />
          </div>
        </div>

        {/* TV Dials/Controls */}
        <div className="TVDials">
          <div className="ChannelDial">
            {channels.map((channel, index) => (
              <button
                key={channel.number}
                className={`ChannelOption ${index === currentChannel ? 'active' : ''} ${
                  liveStatus[channel.username] ? 'live' : 'offline'
                }`}
                onClick={() => handleChannelChange(index)}
                disabled={!liveStatus[channel.username]}
                title={liveStatus[channel.username] ? 'LIVE' : 'OFFLINE'}
              >
                {channel.number}
                {liveStatus[channel.username] && <span className="LiveDot">●</span>}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export default Webcams;
