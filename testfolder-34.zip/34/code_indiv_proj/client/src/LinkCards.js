import './LinkCards.css';
import { useState, useEffect } from 'react';

// Configuration - easily modify this to change links, SVGs, and backgrounds
const cardsData = [
  {
    id: 1,
    url: 'https://github.com/harperkerstens',
    label: 'GitHub',
    svgPath: '/images/github.svg',
    backgroundVideo: '/images/background3.mp4',
    backgroundImage: '/images/background3Static.jpg',
  },
  {
    id: 2,
    url: 'https://www.instagram.com/harperkerstens/',
    label: 'Instagram',
    svgPath: '/images/instagram.svg',
    backgroundVideo: '/images/background2.mp4',
    backgroundImage: '/images/background2Static.jpg',
  },
  {
    id: 3,
    url: 'https://www.linkedin.com/in/harper-kerstens-3a5b65312/',
    label: 'LinkedIn',
    svgPath: '/images/linkedin.svg',
    backgroundVideo: '/images/background1.mp4',
    backgroundImage: '/images/background1Static.jpg',
  },
  {
    id: 4,
    url: 'https://open.spotify.com/user/popharpe',
    label: 'Spotify',
    svgPath: '/images/spotify.svg',
    backgroundVideo: '/images/background4.mp4',
    backgroundImage: '/images/background4Static.jpg',
  },
];

function LinkCards() {
  const [isMobile, setIsMobile] = useState(window.innerWidth <= 768);
  const [carouselIndex, setCarouselIndex] = useState(0);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth <= 768);
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const handlePrevCard = () => {
    setCarouselIndex((prev) => (prev - 1 + cardsData.length) % cardsData.length);
  };

  const handleNextCard = () => {
    setCarouselIndex((prev) => (prev + 1) % cardsData.length);
  };
  return (
    <div className="LinkCardsContainer">
      <div className={`LinkCardsGrid ${isMobile ? 'carousel' : ''}`}>
        {isMobile ? (
          <>
            <button className="CarouselButton CarouselPrev" onClick={handlePrevCard}>
              ‹
            </button>
            <a
              href={cardsData[carouselIndex].url}
              target="_blank"
              rel="noopener noreferrer"
              className="LinkCard CarouselCard"
            >
              <img
                src={cardsData[carouselIndex].backgroundImage}
                alt="background"
                className="CardBackground"
              />
              <img src={cardsData[carouselIndex].svgPath} alt={cardsData[carouselIndex].label} className="CardIcon" />
            </a>
            <button className="CarouselButton CarouselNext" onClick={handleNextCard}>
              ›
            </button>
          </>
        ) : (
          cardsData.map((card) => (
            <a
              key={card.id}
              href={card.url}
              target="_blank"
              rel="noopener noreferrer"
              className="LinkCard"
            >
              <video
                className="CardVideo"
                autoPlay
                loop
                muted
                controlsList="nofullscreen"
                onContextMenu={(e) => e.preventDefault()}
              >
                <source src={card.backgroundVideo} type="video/mp4" />
              </video>
              <img src={card.svgPath} alt={card.label} className="CardIcon" />
            </a>
          ))
        )}
      </div>
    </div>
  );
}

export default LinkCards;
