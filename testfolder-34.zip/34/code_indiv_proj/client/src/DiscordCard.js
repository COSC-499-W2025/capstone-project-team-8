import { useEffect, useState } from 'react';
import './DiscordCard.css';

function DiscordCard() {
  const [discordData, setDiscordData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchDiscordData = async () => {
      try {
        const response = await fetch(
          'https://api.lanyard.rest/v1/users/450101997690159124'
        );
        const data = await response.json();
        
        if (data.success) {
          setDiscordData(data.data);
          setError(null);
        } else {
          setError('Failed to load Discord data');
        }
      } catch (err) {
        setError('Failed to connect to Discord status');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchDiscordData();
    // Refresh every 15 seconds
    const interval = setInterval(fetchDiscordData, 15000);

    return () => clearInterval(interval);
  }, []);

  const getStatusColor = (status) => {
    switch (status) {
      case 'online':
        return '#43b581';
      case 'idle':
        return '#faa61a';
      case 'dnd':
        return '#f04747';
      case 'offline':
        return '#747f8d';
      default:
        return '#747f8d';
    }
  };

  const formatStatus = (status) => {
    return status.charAt(0).toUpperCase() + status.slice(1);
  };

  return (
    <div className="DiscordCardContainer">
      {loading && <div className="DiscordCard">Loading Discord...</div>}
      {error && <div className="DiscordCard error">{error}</div>}
      {discordData && (
        <div className="DiscordCard">
          <div className="DiscordHeader">
            <div className="DiscordAvatar">
              <img
                src={`https://cdn.discordapp.com/avatars/${discordData.discord_user.id}/${discordData.discord_user.avatar}.png`}
                alt="Discord Avatar"
              />
              <div
                className="DiscordStatusIndicator"
                style={{ backgroundColor: getStatusColor(discordData.discord_status) }}
              />
            </div>
            <div className="DiscordInfo">
              <h3>{discordData.discord_user.display_name || discordData.discord_user.username}</h3>
              <p className="DiscordUsername">@{discordData.discord_user.username}</p>
            </div>
          </div>
          <div className="DiscordStatus">
            <span className="StatusDot" style={{ backgroundColor: getStatusColor(discordData.discord_status) }} />
            <span className="StatusText">{formatStatus(discordData.discord_status)}</span>
          </div>
          {discordData.activities && discordData.activities.length > 0 && (
            <div className="DiscordActivities">
              {discordData.activities.map((activity, index) => (
                <div key={index} className="ActivityItem">
                  <p className="ActivityName">{activity.name}</p>
                  {activity.details && <p className="ActivityDetails">{activity.details}</p>}
                  {activity.state && <p className="ActivityState">{activity.state}</p>}
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default DiscordCard;
