import { useRef, useState, useEffect } from 'react';
import './PostIt.css';

function PostIt({ postIt, isSelected, isExpanded, onSelect, onUpdate, onDelete, isPlaced, isPreview }) {
  const [isDrawing, setIsDrawing] = useState(false);
  const [isEditingText, setIsEditingText] = useState(false);
  const [textContent, setTextContent] = useState(postIt.text || '');
  const [signatureContent, setSignatureContent] = useState(postIt.signature || 'Anonymous');
  const canvasRef = useRef(null);
  const thumbnailCanvasRef = useRef(null);
  const postItRef = useRef(null);
  const dragRef = useRef({ offsetX: 0, offsetY: 0 });
  const draggingRef = useRef(false);

  // Initialize main canvas drawing
  useEffect(() => {
    if (canvasRef.current && postIt.drawingData) {
      const ctx = canvasRef.current.getContext('2d');
      const img = new Image();
      img.onload = () => {
        ctx.drawImage(img, 0, 0);
      };
      img.src = postIt.drawingData;
    }
  }, [postIt.drawingData, isExpanded]);

  // Initialize thumbnail canvas
  useEffect(() => {
    if (thumbnailCanvasRef.current && postIt.drawingData && !isExpanded) {
      const ctx = thumbnailCanvasRef.current.getContext('2d');
      const img = new Image();
      img.onload = () => {
        // Scale the image to fit the thumbnail canvas
        ctx.drawImage(img, 0, 0, 90, 60);
      };
      img.src = postIt.drawingData;
    }
  }, [postIt.drawingData, isExpanded]);

  const handleMouseDown = (e) => {
    if (isExpanded) {
      // In expanded mode, allow drawing
      if (e.target === canvasRef.current) {
        startDrawing(e);
      }
    } else if (!isPlaced && !isPreview && (e.target === postItRef.current || e.target.closest('.PostItContent'))) {
      // In board view, only allow dragging if not placed
      startDragging(e);
    }
  };

  // Drawing functions
  const startDrawing = (e) => {
    setIsDrawing(true);
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const ctx = canvas.getContext('2d');
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.strokeStyle = '#333333';
    ctx.lineWidth = 2;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
  };

  const handleCanvasMouseMove = (e) => {
    if (isDrawing && canvasRef.current && isExpanded) {
      const canvas = canvasRef.current;
      const rect = canvas.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;

      const ctx = canvas.getContext('2d');
      ctx.lineTo(x, y);
      ctx.stroke();
    }
  };

  const handleMouseUp = () => {
    if (isDrawing) {
      setIsDrawing(false);
      // Save drawing to state
      const canvas = canvasRef.current;
      onUpdate({ drawingData: canvas.toDataURL() });
    }
  };

  // Dragging functions
  const startDragging = (e) => {
    if (e.button !== 0) return; // Only left mouse button
    if (isExpanded) return; // Don't drag when expanded
    if (isEditingText) return; // Don't drag when editing text
    if (isPlaced || isPreview) return; // Don't drag if placed or in preview

    onSelect();
    const rect = postItRef.current.getBoundingClientRect();
    dragRef.current = {
      offsetX: e.clientX - rect.left,
      offsetY: e.clientY - rect.top,
    };

    draggingRef.current = true;
    document.addEventListener('mousemove', handleDrag);
    document.addEventListener('mouseup', stopDragging);
  };

  const handleDrag = (e) => {
    if (!draggingRef.current || isPlaced || isPreview) return;
    const newX = e.clientX - dragRef.current.offsetX;
    const newY = e.clientY - dragRef.current.offsetY;
    onUpdate({ x: newX, y: newY });
  };

  const stopDragging = () => {
    draggingRef.current = false;
    document.removeEventListener('mousemove', handleDrag);
    document.removeEventListener('mouseup', stopDragging);
  };

  const handleTextChange = (e) => {
    setTextContent(e.target.value);
    onUpdate({ text: e.target.value });
  };

  const handleSignatureChange = (e) => {
    setSignatureContent(e.target.value);
    onUpdate({ signature: e.target.value });
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    onUpdate({ drawingData: null });
  };

  const positionStyle = isExpanded || isPreview
    ? { transform: 'none', position: 'relative', left: 0, top: 0 }
    : { transform: `translate(${postIt.x}px, ${postIt.y}px) rotate(${postIt.rotation}deg)` };

  const cursorStyle = isPlaced || isPreview ? 'pointer' : 'grab';

  return (
    <div
      ref={postItRef}
      className={`PostIt ${isSelected ? 'selected' : ''} ${isPlaced ? 'placed' : ''}`}
      style={positionStyle}
      onClick={() => isPlaced && onSelect()}
      onMouseDown={handleMouseDown}
    >
      <div
        className="PostItContent"
        style={{
          backgroundColor: postIt.color,
          width: isExpanded ? '600px' : '100px',
          height: isExpanded ? 'auto' : '130px',
          cursor: cursorStyle,
        }}
      >
        {isExpanded && (
          <div className="PostItHeader">
            <h3>Edit Post-It</h3>
            <button className="DeleteButton" onClick={() => onDelete()}>Delete</button>
          </div>
        )}

        {/* Thumbnail canvas for board view */}
        {!isExpanded && postIt.drawingData && (
          <canvas
            ref={thumbnailCanvasRef}
            className="PostItCanvasThumbnail"
            width={90}
            height={60}
          />
        )}

        {/* Full canvas for expanded view */}
        {isExpanded && (
          <canvas
            ref={canvasRef}
            className="PostItCanvas"
            width={550}
            height={300}
            onMouseMove={handleCanvasMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseUp}
          />
        )}

        {/* Text area for expanded view */}
        {isExpanded && (
          <textarea
            className="PostItTextArea"
            value={textContent}
            onChange={handleTextChange}
            placeholder="Type or draw on your post-it..."
            onFocus={() => setIsEditingText(true)}
            onBlur={() => setIsEditingText(false)}
          />
        )}

        {/* Text display (non-expanded) */}
        {!isExpanded && textContent && (
          <div className="PostItText">{textContent}</div>
        )}

        {/* Signature input for expanded view */}
        {isExpanded && (
          <div className="PostItSignatureInput">
            <label>Signed by:</label>
            <input
              type="text"
              value={signatureContent}
              onChange={handleSignatureChange}
              placeholder="Your name..."
              maxLength="30"
            />
          </div>
        )}

        {/* Controls for expanded view */}
        {isExpanded && (
          <div className="PostItCanvasControls">
            <button className="ClearCanvasButton" onClick={clearCanvas}>
              Clear Drawing
            </button>
          </div>
        )}

        {/* Signature display (non-expanded) */}
        {!isExpanded && (
          <div className="PostItSignature">
            — {signatureContent}
          </div>
        )}
      </div>
    </div>
  );
}

export default PostIt;
