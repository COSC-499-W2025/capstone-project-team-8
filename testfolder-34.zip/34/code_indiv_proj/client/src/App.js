import './App.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Analytics } from "@vercel/analytics/react";
import Header from './Header';
import AsciiDisplay from './AsciiDisplay';
import LinkCards from './LinkCards';
import LastFmCard from './LastFmCard';
import DiscordCard from './DiscordCard';
import Blog from './Blog';
import PostItBoard from './PostItBoard';
import MusicWidget from './MusicWidget';
import Webcams from './Webcams';
import AlbumReview from './AlbumReview';


function App() {
 

  return (
    <Router>
      <div className="App">
        <Header />
        
        
        <Routes>
          <Route 
            path="/" 
            element={
              <>
                <div style={{ width: '100%', display: 'flex', justifyContent: 'center' }}>
                  <AsciiDisplay />
                </div>
                <div style={{ order: 1, width: '100%', display: 'flex', justifyContent: 'center', gap: '10px', flexWrap: 'wrap', padding: '0 3px', boxSizing: 'border-box', minWidth: 0 }} className="mobile-lastfm">
                  <div style={{ flex: '1 1 clamp(150px, 30vw, 400px)', minWidth: 0 }}>
                    <DiscordCard />
                  </div>
                  <div style={{ flex: '1 1 clamp(150px, 30vw, 400px)', minWidth: 0 }}>
                    <LastFmCard />
                  </div>
                </div>
                <div style={{ order: 2 }} className="mobile-links">
                  <LinkCards />
                </div>
              </>
            } 
          />
          <Route path="/blog" element={<Blog />} />
          <Route path="/post-it-board" element={<PostItBoard />} />
          <Route path="/webcams" element={<Webcams />} />
          <Route path="/albums" element={<AlbumReview />} />
        </Routes>
        <Analytics />
      </div>
    </Router>
  );
}

export default App;
