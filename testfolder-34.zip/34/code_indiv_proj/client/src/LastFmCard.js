import { useEffect, useState } from 'react';
import './LastFmCard.css';

function LastFmCard() {
  const [songData, setSongData] = useState(null);
  const [lastPlayed, setLastPlayed] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isNowPlaying, setIsNowPlaying] = useState(false);

  useEffect(() => {
    const fetchLastFmData = async () => {
      try {
        const response = await fetch(
          'https://lastfm-last-played.biancarosa.com.br/cashidontget/latest-song'
        );
        const data = await response.json();
        setSongData(data);
        
        // Store current as last played for next refresh
        if (data.track) {
          setLastPlayed(data.track);
        }
        
        // Check if track is currently playing
        const nowPlaying = data.track?.['@attr']?.nowplaying === 'true';
        setIsNowPlaying(nowPlaying);
        
        setError(null);
      } catch (err) {
        setError('Failed to load Last.fm data');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchLastFmData();
    // Refresh every 30 seconds
    const interval = setInterval(fetchLastFmData, 30000);

    return () => clearInterval(interval);
  }, []);

  const renderTrackInfo = (track, title) => {
    if (!track) return null;
    
    return (
      <div className="LastFmCard">
        <div className="LastFmContent">
          <h3>{title}</h3>
          <div className="SongInfo">
            <p className="Artist">
              {typeof track.artist === 'string'
                ? track.artist
                : track.artist?.['#text'] || 'Unknown Artist'}
            </p>
            <p className="Song">
              {typeof track.name === 'string'
                ? track.name
                : track.name?.['#text'] || 'Unknown Song'}
            </p>
            {track.album && (
              <p className="Album">
                {typeof track.album === 'string'
                  ? track.album
                  : track.album?.['#text'] || ''}
              </p>
            )}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="LastFmCardContainer">
      {loading && <div className="LastFmCard">Loading...</div>}
      {error && <div className="LastFmCard error">{error}</div>}
      {songData && (
        <div className="LastFmCardsWrapper">
          {renderTrackInfo(songData.track, isNowPlaying ? 'Now Playing' : 'Last Played')}
          {lastPlayed && lastPlayed !== songData.track && (
            renderTrackInfo(lastPlayed, 'Previously Played')
          )}
        </div>
      )}
    </div>
  );
}

export default LastFmCard;
