import { useEffect, useMemo, useState, useRef, useLayoutEffect } from 'react';
import './AsciiDisplay.css';

const asciiArt = `                                                                          
                                         @@@@@@                                                     
                                       @@@@@@@@@@@@@@@                                              
                                       @@@@         @@@@@@@@@                                       
                                   @@@@@@@@@@@@            @@@@@@@                                  
                                   @@@        @@@@@@             @@@@@@@                            
                                   @@@@           @@@@@@@@             @@@@@@                       
                                 @@@@@@@@@             @@@@@@@              @@@@@                   
                                @@@@   @@@@@@@@             @@                  @@@@                
                                @@@         @@@@@@@@@                             @@@@              
                                @@@@              @@@@@@@                           @@@             
                                @@@@@@@@              @@@@@@@                        @@@            
                              @@@@@@@@@@@@@@              @@@@                       @@@            
                        @@@@@@@@@@@@@@ @@@@@@@@@@                                     @@@           
                       @@@  @@@@ @@@@  @@@@@@@@@@@@@@@@                               @@@           
                      @@@@  @@@  @@@@  @@@@ @@@@@@@@@@@@@@@                           @@@           
                     @@@@  @@@@  @@@   @@@@ @@@                                      @@@@           
                     @@@@  @@@  @@@@   @@@@ @@@                                      @@@            
                     @@@  @@@@  @@@@  @@@@  @@@                                      @@@            
                    @@@   @@@   @@@   @@@@  @@@@@@@@@                               @@@             
                   @@@@  @@@@  @@@@   @@@@ @@@@    @@@@@@@@@                       @@@@             
                  @@@@  @@@@   @@@    @@@  @@@@           @@@@@@@@                 @@@              
                  @@@   @@@   @@@@    @@@  @@@@@@@              @@@@@@            @@@               
                 @@@    @@@   @@@     @@@  @@@@@@@@@@               @@@@@         @@@               
                @@@@   @@@@  @@@@    @@@@  @@@     @@@       @@@@@@@@@@@@        @@@               
                @@@    @@@   @@@     @@@  @@@@     @@@@    @@@@@@@@ @@@@@       @@@                
               @@@@   @@@@   @@@          @@@       @@@   @@@@       @@@@      @@@@                
              @@@@                        @@@   @@@@@@@  @@@@        @@@@      @@@                 
              @@@                        @@@@  @@@@@@@@  @@@@        @@@      @@@                  
             @@@@                        @@@@ @@@@@@@@@ @@@@    @@@@@@@@     @@@                   
            @@@@                         @@@  @@@@@@@@  @@@@   @@@@@@@@@    @@@                    
            @@@                          @@@@ @@@@@@@@  @@@   @@@@@@@@@    @@@                     
           @@@@                          @@@@@@@@@@@@@  @@@   @@@@@@@@@   @@@                      
           @@@                           @@@    @@@@@   @@@@@@@@@@@@@@   @@@                       
          @@@@                          @@@@             @@@@@@@@@@@@@  @@@                        
          @@@@                          @@@@  @@@@@@@@@@@@@@@@@@@@@@@@ @@@                         
          @@@                            @@@@@@@@@@@@@@@         @@@@@@@@                          
          @@@                                                 @@@@@@                               
          @@@                                              @@@@@@                                  
          @@@                                           @@@@@@                                     
          @@@@                                       @@@@@@                                        
          @@@@                                   @@@@@@@                                           
          @@@@                                @@@@@@                                               
           @@@@                           @@@@@@@                                                  
             @@@@@                    @@@@@@@                                                      
               @@@@@@@              @@@@@@@                                                        
                     @@@@@@@@@@@@@@@@@@@@@                                                         
                            @@@@@@@@@                                                                

`;

const GLITCH_CHARS = ['$', '%', '*', '#', ' '];
const FIRST_NAME_ART = " _   _                            \n| | | |                           \n| |_| | __ _ _ __ _ __   ___ _ __ \n|  _  |/ _` | '__| '_ \\ / _ \\ '__|\n| | | | (_| | |  | |_) |  __/ |   \n\\_| |_/\\__,_|_|  | .__/ \\___|_|   \n                 | |              \n                 |_|               ";

const LAST_NAME_ART = " _   __              _                 \n| | / /             | |                \n| |/ /  ___ _ __ ___| |_ ___ _ __  ___ \n|    \\ / _ \\ '__/ __| __/ _ \\ '_ \\/ __|\n| |\\  \\  __/ |  \\__ \\ ||  __/ | | \\__ \\\n\\_| \\_/\\___|_|  |___/\\__\\___|_| |_|___/";

function AsciiDisplay() {
  const baseLines = useMemo(() => asciiArt.trimEnd().split('\n'), []);
  const [firstNameLines, firstNameMax] = useMemo(() => {
    const raw = FIRST_NAME_ART.replace(/\r/g, '').trimEnd().split('\n');
    const max = Math.max(...raw.map(l => l.length));
    const padded = raw.map(l => l.padEnd(max));
    return [padded, max];
  }, []);

  const [lastNameLines, lastNameMax] = useMemo(() => {
    const raw = LAST_NAME_ART.replace(/\r/g, '').trimEnd().split('\n');
    const max = Math.max(...raw.map(l => l.length));
    const padded = raw.map(l => l.padEnd(max));
    return [padded, max];
  }, []);

  // Calculate the maximum animation duration for ASCII art
  const asciiAnimationDuration = useMemo(() => {
    const centerLineIndex = Math.floor(baseLines.length / 2);
    const durations = baseLines.map((text, index) => {
      const baseDuration = 1.5;
      const distanceFromCenter = Math.abs(index - centerLineIndex);
      const delay = distanceFromCenter * 0.08;
      // This is a fixed calculation since we use random in the actual component
      const variation = 0; // Use average instead
      const duration = Math.max(0.75, baseDuration + variation);
      return duration + delay;
    });
    return Math.max(...durations);
  }, [baseLines]);

  const animatedFirstName = useMemo(() => (
    firstNameLines.map((text, index) => {
      const baseDuration = 1.4; // seconds
      const variation = (Math.random() * 1.0) - 0.5;
      const duration = Math.max(0.5, baseDuration + variation);
      return { text, duration, key: `first-${index}-${text}` };
    })
  ), [firstNameLines]);

  const animatedLastName = useMemo(() => (
    lastNameLines.map((text, index) => {
      const baseDuration = 1.4; // seconds
      const variation = (Math.random() * 1.0) - 0.5;
      const duration = Math.max(0.5, baseDuration + variation);
      return { text, duration, key: `last-${index}-${text}` };
    })
  ), [lastNameLines]);

  const animatedLines = useMemo(() => {
    const centerLineIndex = Math.floor(baseLines.length / 2);
    return baseLines.map((text, index) => {
      const baseDuration = 1.5; // seconds
      const variation = (Math.random() * 4) - 2; // -2 to +2 seconds
      const duration = Math.max(0.75, baseDuration + variation);
      // Calculate distance from center for ripple effect
      const distanceFromCenter = Math.abs(index - centerLineIndex);
      return { text, duration, key: `${index}-${text}`, distanceFromCenter };
    })
  }, [baseLines]);

  const [glitches, setGlitches] = useState({});
  const shellRef = useRef(null);
  const [fontSizePx, setFontSizePx] = useState(null);

  // Dynamically calculate font size based on available width
  useLayoutEffect(() => {
    const shell = shellRef.current;
    if (!shell) return;

    const calculateFontSize = () => {
      const width = shell.clientWidth;
      const totalEstimatedChars = 160; // rough estimate of total chars needed
      const availableWidth = Math.max(100, width - 30);
      const charWidth = availableWidth / totalEstimatedChars;
      const size = Math.max(6, Math.min(28, Math.floor(charWidth)));
      setFontSizePx(size);
    };

    calculateFontSize();

    const resizeObserver = new ResizeObserver(() => {
      calculateFontSize();
    });
    resizeObserver.observe(shell);

    return () => resizeObserver.disconnect();
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setGlitches((prev) => {
        const now = performance.now();
        const cleanedEntries = Object.entries(prev).filter(([, data]) => data.until > now);
        const cleaned = Object.fromEntries(cleanedEntries);

        const active = cleanedEntries.length;
        if (active >= 10) {
          return cleaned;
        }

        if (Math.random() < 0.8) {
          const lineIndex = Math.floor(Math.random() * baseLines.length);
          const line = baseLines[lineIndex] ?? '';
          if (line.length === 0) return cleaned;

          const atIndices = [];
          for (let i = 0; i < line.length; i += 1) {
            if (line[i] === '@') atIndices.push(i);
          }
          if (atIndices.length === 0) return cleaned;

          const charIndex = atIndices[Math.floor(Math.random() * atIndices.length)];
          const key = `${lineIndex}-${charIndex}`;
          if (cleaned[key]) return cleaned;

          const durationMs = 120 + Math.random() * 220; // 120–340ms
          const until = now + durationMs;
          const glitchChar = GLITCH_CHARS[Math.floor(Math.random() * GLITCH_CHARS.length)];

          return {
            ...cleaned,
            [key]: { char: glitchChar, until }
          };
        }

        return cleaned;
      });
    }, 80);

    return () => clearInterval(interval);
  }, [baseLines]);

  return (
    <div className="Shell" ref={shellRef} style={{ fontSize: fontSizePx ? `${fontSizePx}px` : undefined, overflowX: 'hidden' }}>
      <div className="NameBlock NameBlock-left">
        {animatedFirstName.map(({ text, duration, key }, index) => (
          <div
            className="NameLine"
            style={{ '--duration': `${duration}s`, '--steps': text.length, '--max': `${firstNameMax}ch`, '--line-index': index, '--ascii-duration': `${asciiAnimationDuration}s` }}
            key={key}
          >
            {text}
          </div>
        ))}
      </div>
      <div className="Center">
        {animatedLines.map(({ text, duration, key, distanceFromCenter }, index) => (
          <div
            className="Line"
            style={{ '--duration': `${duration}s`, '--steps': text.length, '--line-index': index, '--distance': distanceFromCenter }}
            key={key}
          >
            {text.split('').map((char, charIndex) => {
              const glitchKey = `${key.split('-')[0]}-${charIndex}`;
              const displayChar = glitches[glitchKey]?.char ?? char;
              return (
                <span className="LineChar" key={`${glitchKey}-${char}`}>
                  {displayChar}
                </span>
              );
            })}
          </div>
        ))}
      </div>
      <div className="NameBlock NameBlock-right">
        {animatedLastName.map(({ text, duration, key }, index) => (
          <div
            className="NameLine"
            style={{ '--duration': `${duration}s`, '--steps': text.length, '--max': `${lastNameMax}ch`, '--line-index': index, '--ascii-duration': `${asciiAnimationDuration}s` }}
            key={key}
          >
            {text}
          </div>
        ))}
      </div>
    </div>
  );
}

export default AsciiDisplay;
