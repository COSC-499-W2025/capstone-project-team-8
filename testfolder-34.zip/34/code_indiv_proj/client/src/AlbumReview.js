import './AlbumReview.css';
import { useState } from 'react';

// Configuration - Add your albums here
const albumsData = [
  {
    id: 1,
    artist: 'Childish Gambino',
    albumName: 'Because the Internet',
    coverImage: 'images/album-covers/becausetheinternet.jpg',
    review: 'This album was one of my first experiences with listening to rap as a child. I have to acknowledge the potential for bias there lol. Still, I find this album to be deeply meaningful and has stood the test of time insanley well. This album was created as an experience, and listening to it front to back that is truly felt. Having something to say in each song Donald Glover did his big one creating deeply impactful moments each of which cater to a different sentiment. However much I love this album I have found myself skipping songs like Crawl and Worldstar often, they\'re both solid songs but I just don\'t find myself in the mood for extreme energy like that often. Overall still one of my top favourite albums of all time\.',
    rating: 9.6,
    favoriteTrack: 'Flight of the Navigator',
    spotifyUrl: 'https://open.spotify.com/album/5h0KYWMZIg8xT6eRGYkNMh',
    appleMusicUrl: 'https://music.apple.com/us/album/because-the-internet/1771709429',
    releaseYear: 2013,
    dominantColor: '#c87088',
  },
  {
    id: 2,
    artist: 'MIKE',
    albumName: 'Showbiz!',
    coverImage: '/images/album-covers/Showbiz!.jpg',
    review: 'This album really stood out to me in the year of 2025 and was my personal favourite album to release this year. I found myself going back to it constantly, the album has an extremely consistent listening experience. MIKE had a clear vision in mind for this album and it payed off immensely. Some songs didn\'t feel super impactful for me, however I wouldn\'t say this is anything negative about the album. Even with those songs that don\'t resonate with me I never found them to be bad or unlistenable, they really just didn\'t connect with me personally. Just an incredible album through and through.',
    rating: 9.0,
    favoriteTrack: 'Spun Out',
    spotifyUrl: 'https://open.spotify.com/album/3M1PhSsHmAlh79bAz9jBZs',
    appleMusicUrl: 'https://music.apple.com/us/album/showbiz/1788674268',
    releaseYear: 2025,
    dominantColor: '#174173',
  },
  {
    id: 3,
    artist: 'JID',
    albumName: 'The Never Story',
    coverImage: '/images/album-covers/theneverstory.png',
    review: 'Ill never forget the first time I heard about JID, it was during lunch in middle school when the 2018 XXL Freshman list dropped and I thought \"who the fuck is this guy?\". Being a huge soundcloud rap fan, Wifisfuneral was more of what I was into, I could have never guessed that flash foreward to now he would be one of my favourite artist. In this album you can tell JID is still figuring out his sound and there\'s some things to polish but the potential is so evident. Each song is so amazing. I love so much of this album and would truly argue it\'s a no skip album. Although most people are only familiar with NEVER (very fair tbh a crazy good song) I found myself draw to it\'s more melodic tracks. But obviously when you combine JID\'s emerging talent in melodic songs and his insane lyricism its bound to be a great listening experience. If you\'re only familiar with his never stuff I beg you to give this a listen you will enjoy it. ',
    rating: 9.3,
    favoriteTrack: 'LAUDER',
    spotifyUrl: 'https://open.spotify.com/album/1gPqbxhs90kppgOVxGOPzd',
    appleMusicUrl: 'https://music.apple.com/ca/album/the-never-story/1440883057',
    dominantColor: '#ef9b08',
    releaseYear: 2017,
  },
  {
    id: 4,
    artist: 'Freddie Gibbs & Madlib',
    albumName: 'Bandana',
    coverImage: '/images/album-covers/bandana.jpeg',
    review: 'When you put Freddie Gibbs and any compentent producer together it\'s bound to be good, let alone a producer like Madlib. This album is an amazing listen. Each song is so good and I\'ve never been mad to hear a song from this album come on. Just amazing beats and Freddie Gibbs obviously does his thing. Some songs I find kind of get a little drawn out at points but I feel like this could be a niche complaint so I don\'t hold it against the album at all. Just straight gas throughout is all I can really say tbh.',
    rating: 9.4,
    favoriteTrack: 'Fake Names',
    spotifyUrl: 'https://open.spotify.com/album/31KbO7WnDp2AjPdmRTJzdf',
    dominantColor: '#084c63',
    appleMusicUrl: 'https://music.apple.com/us/album/bandana/1464243671',
    releaseYear: 2019,
  },
  {
    id: 5,
    artist: 'A$AP Rocky',
    albumName: 'Long.Live.A$AP',
    coverImage: '/images/album-covers/longliveasap.jpg',
    review: 'A$AP Rocky really took a while to grow on me, I wasn\'t super into him the first few times I heard his stuff. Since hearing some standout tracks and deciding to try again, he quickly has grown on me becoming one my favourite artists. The beat producition on this album is incredible, alongside some really solid work from A$AP himself. From tracks like Goldie and Angels giving upbeat energy to more calm tracks like fashion killer, this album is super solid all around. Saying this though, I do find there to be some skips for sure and the album has it\'s low points. BUT I would absolutely recommend this album and it\'s worth a listen for sure. ',
    rating: 8.7,
    favoriteTrack: 'Angels',
    spotifyUrl: 'https://open.spotify.com/album/3JOwVvS1RUY8SKPZy7Bu7K',
    dominantColor: '#ecedef',
    appleMusicUrl: 'https://music.apple.com/us/album/long-live-a%24ap/581997129',
    releaseYear: 2013,
  },
  {
    id: 6,
    artist: 'Vince Staples',
    albumName: "Summertime '06",
    coverImage: '/images/album-covers/summertimein06.jpg',
    review: 'My first experience with Vince Staples was through that video of the mom reaction to Norf Norf. I was probably draw to that song because it was just presented in a rebelious nature through that video. Since then years later I decided to give the whole album a listen and found myself baffled at what I was hearing. I fell in love with a lot of the tracks and was shocked at the diversity of sound in this album, going in I found myself expecting just more of Norf Norf. Songs like Summertime are such a departure from the violent sentiment of other tracks in this album while maintaing a really strong emotional depcition for Vince. Overall this is a realy strong album but I do find it\'s low points being decently low and there\'s some songs I got little to no value out of. However that doesn\'t change things for me I still would easily recommend this album to anyone curious.',
    rating: 9,
    favoriteTrack: 'Lift Me Up',
    dominantColor: '#f1f2d3',
    spotifyUrl: 'https://open.spotify.com/album/4Csoz10NhNJOrCTUoPBdUD',
    appleMusicUrl: 'https://music.apple.com/ca/album/summertime-06/1444178693',
    releaseYear: 2015,
  },
   {
    id: 7,
    artist: 'Daniel Caesar',
    albumName: 'CASE STUDY 01',
    coverImage: '/images/album-covers/casestudy01.jpg',
    review: 'I\'ll never forget my first listen of this album, me and a friend were up late playing minecraft waiting for it\'s release and when it came out we played the whole thing front to back. During the tracks we wouldn\'t say much, just sharing our thoughts at the end of a track. This is for sure a more emotional listen which is something Daniel Caesar has always done really well. Truly there are no songs on this I would skip and I find myself coming back to this album at least twice a year and enjoying it thoroughly. To me this is Daniel Caesar at his best',
    rating: 9.5,
    dominantColor: '#567b98',
    favoriteTrack: 'CYANIDE',
    spotifyUrl: 'https://open.spotify.com/album/4mvxoogQn8p84Wz17zTHnJ',
    appleMusicUrl: 'https://music.apple.com/us/album/case-study-01/1799080239',
    releaseYear: 2019,
  },
   {
    id: 8,
    artist: 'Brent Faiyaz',
    albumName: 'Fuck The World',
    coverImage: '/images/album-covers/fucktheworld.png',
    review: 'If you\'re familiar with Brent Faiyaz earlier work, this album is a notable shift from his previous stuff like Sonder son. Moving away from a more traditional intrusment makeup per song, there\'s a lot more work going on to create a more atmospheric sound. Brent really goes all in on embracing the cool guy persona and it\'s really reflected in the music. I really enjoy this album but I do find that sometimes I get tired of some of the songs, not all the tracks land for me and that\'s okay. It\'s part of the risk when going for an album like the one Brent is tring to create here. Overall I still love this body of work and would recoomend it to anybody who enjoys R&B.',
    rating: 8.7,
    favoriteTrack: 'Rehab (Winter in Paris)',
    spotifyUrl: 'https://open.spotify.com/album/3vi20DRHkqv4HyVg9Rt9wC',
    appleMusicUrl: 'https://music.apple.com/mm/album/fuck-the-world/1488013862',
    releaseYear: 2020,
  },
   {
    id: 9,
    artist: 'Playboi Carti',
    albumName: 'Die Lit',
    coverImage: '/images/album-covers/dielit.jpg',
    dominantColor: '#ffffff',
    review: 'This album to me is easily Playboi Carti\'s best work, each song has such a unique energy to it making this album such an exciting listen. So many songs are so exillerating with the more calm songs being a great listen. Amazing production alongside amazing features really help round out this album, there\'s some really good performances from both Travis Scott and Bryson Tiller, but truly every feature does their job here. If your\'e invested in Playboi Carti to any level I would recommend this, however, I can acknowldge how he\'s not really for everyone and I can see why some wouldn\'t like him or this album.',
    rating: 9.2,
    favoriteTrack: 'Fell in Luv',
    spotifyUrl: 'https://open.spotify.com/album/7dAm8ShwJLFm9SaJ6Yc58O',
    appleMusicUrl: 'https://music.apple.com/us/album/die-lit/1381553184',
    releaseYear: 2018,
  },
];

function AlbumReview() {
  const [expandedId, setExpandedId] = useState(null);

  const toggleExpand = (id) => {
    setExpandedId(expandedId === id ? null : id);
  };

  return (
    <div className="AlbumReview">
      <div className="AlbumReviewContainer">
        <pre className="AlbumReviewTitle AlbumReviewAscii">{`   ___   _     ______ _   ____  ___ _____ 
 / _ \\ | |    | ___ \\ | | |  \\/  |/  ___|
/ /_\\ \\| |    | |_/ / | | | .  . |\\ \`--. 
|  _  || |    | ___ \\ | | | |\\/| | \`--. \\
| | | || |____| |_/ / |_| | |  | |/\\__/ /
\\_| |_/\\_____/\\____/ \\___/\\_|  |_/\\____/`}</pre>
        <h1 className="AlbumReviewTitle AlbumReviewText">Albums</h1>
        
        <div className="VinylShelf">
          {albumsData.map((album) => (
            <div
              key={album.id}
              className={`VinylItem ${expandedId === album.id ? 'expanded' : ''}`}
              style={{ '--album-color': album.dominantColor || '#64c8ff' }}
            >
              <div 
                className="VinylCover"
                onClick={() => toggleExpand(album.id)}
              >
                <img
                  src={album.coverImage}
                  alt={`${album.albumName} cover`}
                  className="CoverImage"
                />
                <div className="AlbumLabel">
                  <p className="AlbumName">{album.albumName}</p>
                  <p className="ArtistName">{album.artist}</p>
                </div>
              </div>

              {expandedId === album.id && (
                <div 
                  className="ExpandedReviewOverlay" 
                  onClick={() => toggleExpand(album.id)}
                  style={{ '--album-color': album.dominantColor || '#64c8ff' }}
                >
                  <div className="ExpandedReviewContainer" onClick={(e) => e.stopPropagation()}>
                    <div className="ExpandedImage">
                      <img
                        src={album.coverImage}
                        alt={`${album.albumName} cover`}
                      />
                    </div>
                    <div className="ReviewContent">
                      <div className="ReviewHeader">
                        <h2>{album.albumName}</h2>
                        <p className="ArtistInfo">{album.artist} • {album.releaseYear}</p>
                      </div>

                      <div className="Rating">
                        <span className="RatingLabel">Rating:</span>
                        <span className="RatingValue">{album.rating}/10</span>
                      </div>

                      <div className="ReviewScrollable">
                        <h3 className="ReviewTitle">Review</h3>
                        <p className="ReviewText">{album.review}</p>

                        <h3 className="ReviewTitle">Favourite Track</h3>
                        <p className="FavoriteTrackText">{album.favoriteTrack}</p>
                      </div>

                      <div className="StreamingLinks">
                        <a
                          href={album.spotifyUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="StreamingButton spotify"
                        >
                          <img src="/images/spotify.svg" alt="Spotify" />
                          Spotify
                        </a>
                        <a
                          href={album.appleMusicUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="StreamingButton apple"
                        >
                          <img src="/apple.svg" alt="Apple Music" />
                          Apple Music
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default AlbumReview;
