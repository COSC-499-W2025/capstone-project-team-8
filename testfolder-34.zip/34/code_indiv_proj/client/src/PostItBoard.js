import { useState, useEffect, useRef } from 'react';
import { database } from './firebaseConfig';
import { ref, onValue, set, update, remove } from 'firebase/database';
import './PostItBoard.css';
import PostIt from './PostIt';

function PostItBoard() {
  const [postIts, setPostIts] = useState([]);
  const [selectedPostIt, setSelectedPostIt] = useState(null);
  const [isCreating, setIsCreating] = useState(false);
  const [previewPostIt, setPreviewPostIt] = useState(null);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const boardRef = useRef(null);

  // Load post-its from Firebase on mount
  useEffect(() => {
    const postItsRef = ref(database, 'postIts');
    const unsubscribe = onValue(postItsRef, (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.val();
        setPostIts(Object.values(data));
      } else {
        setPostIts([]);
      }
    });

    return () => unsubscribe();
  }, []);

  // Track mouse position for preview mode
  useEffect(() => {
    const handleMouseMove = (e) => {
      setMousePos({ x: e.clientX, y: e.clientY });
    };

    const handleKeyDown = (e) => {
      if (previewPostIt && e.key === 'Escape') {
        cancelPreview();
      }
    };

    if (previewPostIt) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('keydown', handleKeyDown);
      return () => {
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('keydown', handleKeyDown);
      };
    }
  }, [previewPostIt]);

  const createNewPostIt = () => {
    setIsCreating(true);
  };

  const completePostIt = (postItData) => {
    // Create the post-it in preview mode for placement
    const newPostIt = {
      id: Date.now(),
      x: 0,
      y: 0,
      text: postItData.text,
      drawingData: postItData.drawingData,
      rotation: Math.random() * 6 - 3,
      color: postItData.color,
      signature: postItData.signature,
      isPlaced: false, // Not placed yet
    };
    setPreviewPostIt(newPostIt);
    setIsCreating(false);
  };

  const placePostIt = () => {
    if (previewPostIt) {
      const placedPostIt = { 
        ...previewPostIt, 
        isPlaced: true,
        x: mousePos.x - 70,
        y: mousePos.y - 90
      };
      const postItRef = ref(database, `postIts/${placedPostIt.id}`);
      set(postItRef, placedPostIt);
      setPreviewPostIt(null);
    }
  };

  const cancelPreview = () => {
    setPreviewPostIt(null);
  };

  const updatePostIt = (id, updates) => {
    const postItRef = ref(database, `postIts/${id}`);
    update(postItRef, updates);
  };

  const deletePostIt = (id) => {
    const postItRef = ref(database, `postIts/${id}`);
    remove(postItRef);
    if (selectedPostIt?.id === id) {
      setSelectedPostIt(null);
    }
  };

  return (
    <div className="PostItBoardContainer">
      <div className="PostItHeader">
        <pre>{`______         _        _____ _____ _ 
| ___ \\       | |      |_   _|_   _| |
| |_/ /__  ___| |_ ______| |   | | | |
|  __/ _ \\/ __| __|______| |   | | | |
| | | (_) \\__ \\ |_      _| |_  | | |_|
\\_|  \\___/|___/\\__|     \\___/  \\_/ (_)`}</pre>
      </div>
      <div className="PostItBoard" ref={boardRef}>
        {postIts.map(postIt => (
          <PostIt
            key={postIt.id}
            postIt={postIt}
            isSelected={selectedPostIt?.id === postIt.id}
            onSelect={() => {
              if (postIt.isPlaced) {
                setSelectedPostIt(postIt);
              }
            }}
            onUpdate={(updates) => updatePostIt(postIt.id, updates)}
            onDelete={() => deletePostIt(postIt.id)}
            isPlaced={true}
          />
        ))}

        {/* Preview post-it following cursor */}
        {previewPostIt && (
          <div
            className="PreviewPostIt"
            style={{
              left: `${mousePos.x}px`,
              top: `${mousePos.y}px`,
            }}
            onClick={placePostIt}
          >
            <PostIt
              postIt={previewPostIt}
              isSelected={false}
              onSelect={() => {}}
              onUpdate={() => {}}
              onDelete={() => {}}
              isPlaced={false}
              isPreview={true}
            />
          </div>
        )}
      </div>

      {/* Creation modal */}
      {isCreating && (
        <CreatePostItModal
          onComplete={completePostIt}
          onCancel={() => setIsCreating(false)}
        />
      )}

      {/* Expansion modal for placed post-its */}
      {selectedPostIt && (
        <div className="PostItOverlay" onClick={() => setSelectedPostIt(null)}>
          <div className="ExpandedPostItViewOnly" onClick={(e) => e.stopPropagation()}>
            <button className="CloseExpandedButton" onClick={() => setSelectedPostIt(null)}>×</button>
            <div className="ViewOnlyContent" style={{ backgroundColor: selectedPostIt.color }}>
              {selectedPostIt.drawingData && (
                <canvas
                  className="ViewOnlyCanvas"
                  width={550}
                  height={300}
                  ref={(canvas) => {
                    if (canvas && selectedPostIt.drawingData) {
                      const ctx = canvas.getContext('2d');
                      const img = new Image();
                      img.onload = () => {
                        ctx.drawImage(img, 0, 0);
                      };
                      img.src = selectedPostIt.drawingData;
                    }
                  }}
                />
              )}
              {selectedPostIt.text && (
                <div className="ViewOnlyText">{selectedPostIt.text}</div>
              )}
              <div className="ViewOnlySignature">— {selectedPostIt.signature}</div>
            </div>
          </div>
        </div>
      )}

      {/* Preview mode instructions */}
      {previewPostIt && (
        <div className="PreviewInstructions">
          <p>Click to place your post-it on the board • Press ESC to cancel</p>
        </div>
      )}

      <div className="PostItControls">
        <button className="CreatePostItButton" onClick={createNewPostIt}>
          + Create Post-It
        </button>
      </div>
    </div>
  );
}

function CreatePostItModal({ onComplete, onCancel }) {
  const [text, setText] = useState('');
  const [signature, setSignature] = useState('Anonymous');
  const [color, setColor] = useState('#FFE66D');
  const [drawingData, setDrawingData] = useState(null);
  const canvasRef = useRef(null);
  const [isDrawing, setIsDrawing] = useState(false);

  const colors = ['#FFE66D', '#95E1D3', '#F38181', '#AA96DA', '#FCBAD3'];

  const handleCanvasMouseDown = (e) => {
    setIsDrawing(true);
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const ctx = canvas.getContext('2d');
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.strokeStyle = '#333333';
    ctx.lineWidth = 2;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
  };

  const handleCanvasMouseMove = (e) => {
    if (isDrawing && canvasRef.current) {
      const canvas = canvasRef.current;
      const rect = canvas.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;

      const ctx = canvas.getContext('2d');
      ctx.lineTo(x, y);
      ctx.stroke();
    }
  };

  const handleCanvasMouseUp = () => {
    if (isDrawing) {
      setIsDrawing(false);
      setDrawingData(canvasRef.current.toDataURL());
    }
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    setDrawingData(null);
  };

  const handleComplete = () => {
    onComplete({
      text,
      signature,
      color,
      drawingData,
    });
  };

  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'Escape') {
        onCancel();
      }
    };
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [onCancel]);

  return (
    <div className="CreatePostItOverlay" onClick={onCancel}>
      <div className="CreatePostItModal" style={{ backgroundColor: color }} onClick={(e) => e.stopPropagation()}>
        <h2>Create Your Post-It</h2>

        <div className="ModalContent">
          <div className="ModalSection">
            <label>Draw or Write</label>
            <canvas
              ref={canvasRef}
              className="ModalCanvas"
              width={600}
              height={350}
              onMouseDown={handleCanvasMouseDown}
              onMouseMove={handleCanvasMouseMove}
              onMouseUp={handleCanvasMouseUp}
              onMouseLeave={handleCanvasMouseUp}
            />
            <button className="ModalClearButton" onClick={clearCanvas}>
              Clear
            </button>
          </div>

          <div className="ModalSection">
            <label>Text Content</label>
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Type text or leave blank to draw only..."
            />
          </div>

          <div className="ModalSection">
            <label>Your Signature</label>
            <input
              type="text"
              value={signature}
              onChange={(e) => setSignature(e.target.value)}
              placeholder="Your name..."
              maxLength="30"
            />
          </div>

          <div className="ModalSection">
            <label>Color</label>
            <div className="ColorPicker">
              {colors.map((c) => (
                <div
                  key={c}
                  className={`ColorOption ${color === c ? 'selected' : ''}`}
                  style={{ backgroundColor: c }}
                  onClick={() => setColor(c)}
                />
              ))}
            </div>
          </div>
        </div>

        <div className="ModalButtons">
          <button className="ModalCancelButton" onClick={onCancel}>
            Cancel
          </button>
          <button className="ModalCreateButton" onClick={handleComplete}>
            Create & Place
          </button>
        </div>
      </div>
    </div>
  );
}

export default PostItBoard;
