<nav class="mobile-nav">
    <div class="sidebar-menu">
        <a href="homepage.php" class="sidebar-menu__item sidebar-menu__item--active">
            <img src="../assets/svg/home.svg" class="sidebar-menu__item-icon" />
        </a>
        <a href="" class="sidebar-menu__item">
            <img src="../assets/svg/explore.svg" class="sidebar-menu__item-icon" />
        </a>
        <a href="" class="sidebar-menu__item">
            <img src="../assets/svg/notifications.svg" class="sidebar-menu__item-icon" />
        </a>
        <a href="profile.php" class="sidebar-menu__item">
            <img src="../assets/svg/profile.svg" class="sidebar-menu__item-icon" />
        </a>
    </div>
</nav>
